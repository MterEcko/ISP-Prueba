// Plugin ${plugin}
module.exports = {
  name: '${plugin}',
  version: '1.0.0',
  activate: function() {
    console.log('Plugin ${plugin} activated');
  },
  deactivate: function() {
    console.log('Plugin ${plugin} deactivated');
  }
};
