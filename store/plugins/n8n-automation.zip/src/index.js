// Plugin n8n Automation
module.exports = {
  name: 'n8n-automation',
  version: '1.0.0',
  description: 'Automatización con n8n',
  
  async activate(app) {
    console.log('✅ Plugin n8n-automation activado');
    // Aquí iría la integración con n8n
  },
  
  async deactivate() {
    console.log('❌ Plugin n8n-automation desactivado');
  }
};
