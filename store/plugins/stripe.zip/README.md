# Plugin: stripe

Este es un plugin de ejemplo para el marketplace ISP-Prueba.

## Instalación
El plugin se instala automáticamente a través del marketplace.

## Uso
El plugin se activa automáticamente después de la instalación.
